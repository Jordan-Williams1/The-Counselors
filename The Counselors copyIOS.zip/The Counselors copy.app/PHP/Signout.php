<?php session_start();



session_destroy(); // Destroy session on logout
?>